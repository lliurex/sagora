<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>CAboutDlg</name>
    <message>
        <location filename="../util.cpp" line="355"/>
        <source>The </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="356"/>
        <source> software enables musicians to perform real-time jam sessions over the internet. There is a </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="357"/>
        <source> server which collects the audio data from each </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="359"/>
        <source> client, mixes the audio data and sends the mix back to each client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="375"/>
        <source> uses the following libraries, resources or code snippets:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="399"/>
        <source>About </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="416"/>
        <source>, Version </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="427"/>
        <source>Internet Jam Session Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="438"/>
        <source>Under the GNU General Public License (GPL)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAboutDlgBase</name>
    <message>
        <location filename="../aboutdlgbase.ui" line="20"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdlgbase.ui" line="79"/>
        <source>TextLabelVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdlgbase.ui" line="128"/>
        <source>Author: Volker Fischer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdlgbase.ui" line="138"/>
        <source>Copyright (C) 2005-2020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdlgbase.ui" line="238"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAnalyzerConsole</name>
    <message>
        <location filename="../analyzerconsole.cpp" line="50"/>
        <source>Analyzer Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../analyzerconsole.cpp" line="69"/>
        <source>Error Rate of Each Buffer Size</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CChannelFader</name>
    <message>
        <location filename="../audiomixerboard.cpp" line="110"/>
        <source>&lt;b&gt;Channel Level:&lt;/b&gt; Displays the pre-fader audio level of this channel.  All connected clients at the server will be assigned an audio level, the same value for each client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="113"/>
        <source>Input level of the current audio channel at the server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="116"/>
        <source>&lt;b&gt;Mixer Fader:&lt;/b&gt; Adjusts the audio level of this channel. All connected clients at the server will be assigned an audio fader at each client, adjusting the local mix.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="119"/>
        <source>Local mix level setting of the current audio channel at the server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="122"/>
        <source>&lt;b&gt;Mute:&lt;/b&gt; With the Mute checkbox, the audio channel can be muted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="124"/>
        <source>Mute button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="126"/>
        <source>&lt;b&gt;Solo:&lt;/b&gt; With the Solo checkbox, the audio channel can be set to solo which means that all other channels except of the current channel are muted. It is possible to set more than one channel to solo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="130"/>
        <source>Solo button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="132"/>
        <source>&lt;b&gt;Fader Tag:&lt;/b&gt; The fader tag identifies the connected client. The tag name, the picture of your instrument and a flag of your country can be set in the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="137"/>
        <source>Mixer channel instrument picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="139"/>
        <source>Mixer channel label (fader tag)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="141"/>
        <source>Mixer channel country flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="176"/>
        <source>MUTE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="179"/>
        <source>SOLO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="185"/>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../audiomixerboard.cpp" line="186"/>
        <source>Solo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CChatDlg</name>
    <message>
        <location filename="../chatdlg.cpp" line="37"/>
        <source>&lt;b&gt;Chat Window:&lt;/b&gt; The chat window shows a history of all chat messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../chatdlg.cpp" line="40"/>
        <source>Chat history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../chatdlg.cpp" line="43"/>
        <source>&lt;b&gt;Input Message Text:&lt;/b&gt; Enter the chat message text in the edit box and press enter to send the message to the server which distributes the message to all connected clients. Your message will then show up in the chat window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../chatdlg.cpp" line="48"/>
        <source>New chat text edit box</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CChatDlgBase</name>
    <message>
        <location filename="../chatdlgbase.ui" line="19"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../chatdlgbase.ui" line="59"/>
        <source>Cl&amp;ear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../chatdlgbase.ui" line="69"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CClientDlg</name>
    <message>
        <location filename="../clientdlg.cpp" line="51"/>
        <source>&lt;b&gt;Input Level Meter:&lt;/b&gt; The input level indicators show the input level of the two stereo channels of the current selected audio input.&lt;br&gt;Make sure not to clip the input signal to avoid distortions of the audio signal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="57"/>
        <source>If the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="58"/>
        <source> software is connected and you play your instrument/sing in the microphone, the LED level meter should flicker. If this is not the case, you have probably selected the wrong input channel (e.g. line in instead of the microphone input) or set the input gain too low in the (Windows) audio mixer.&lt;br&gt;For a proper usage of the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="64"/>
        <source> software, you should not hear your singing/instrument in the loudspeaker or your headphone when the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="67"/>
        <source> software is not connected. This can be achieved by muting your input audio channel in the Playback mixer (&lt;b&gt;not&lt;/b&gt; the Recording mixer!).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="71"/>
        <source>Input level meter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="72"/>
        <source>Simulates an analog LED level meter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="87"/>
        <source>&lt;b&gt;Connect / Disconnect Button:&lt;/b&gt; Push this button to connect a server. A dialog where you can select a server will open. If you are connected, pressing this button will end the session.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="93"/>
        <source>Connect and disconnect toggle button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="95"/>
        <source>Clicking on this button changes the caption of the button from Connect to Disconnect, i.e., it implements a toggle functionality for connecting and disconnecting the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="98"/>
        <location filename="../clientdlg.cpp" line="158"/>
        <source> software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="101"/>
        <source>&lt;b&gt;Local Audio Input Fader:&lt;/b&gt; With the audio fader, the relative levels of the left and right local audio channels can be changed. For a mono signal it acts like a panning between the two channels. If, e.g., a microphone is connected to the right input channel and an instrument is connected to the left input channel which is much louder than the microphone, move the audio fader in a direction where the label above the fader shows &lt;i&gt;L -x&lt;/i&gt;, where &lt;i&gt;x&lt;/i&gt; is the current attenuation indicator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="114"/>
        <source>Local audio input fader (left/right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="117"/>
        <source>&lt;b&gt;Reverberation Level:&lt;/b&gt; A reverberation effect can be applied to one local mono audio channel or to both channels in stereo mode. The mone channel selection and the reverberation level can be modified. If, e.g., the microphone signal is fed into the right audio channel of the sound card and a reverberation effect shall be applied, set the channel selector to right and move the fader upwards until the desired reverberation level is reached.&lt;br&gt;The reverberation effect requires significant CPU so that it should only be used on fast PCs. If the reverberation level fader is set to minimum (which is the default setting), the reverberation effect is switched off and does not cause any additional CPU usage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="133"/>
        <source>Reverberation effect level setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="136"/>
        <source>&lt;b&gt;Reverberation Channel Selection:&lt;/b&gt; With these radio buttons the audio input channel on which the reverberation effect is applied can be chosen. Either the left or right input channel can be selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="142"/>
        <source>Left channel selection for reverberation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="144"/>
        <source>Right channel selection for reverberation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="147"/>
        <source>&lt;b&gt;Delay Status LED:&lt;/b&gt; The delay status LED indicator shows the current audio delay status. If the light is green, the delay is perfect for a jam session. If the light is yellow, a session is still possible but it may be harder to play. If the light is red, the delay is too large for jamming.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="156"/>
        <source>If this LED indicator turns red, you will not have much fun using the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="160"/>
        <source>Delay status LED indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="163"/>
        <source>&lt;b&gt;Buffers Status LED:&lt;/b&gt; The buffers status LED indicator shows the current audio/streaming status. If the light is green, there are no buffer overruns/underruns and the audio stream is not interrupted. If the light is red, the audio stream is interrupted caused by one of the following problems:&lt;ul&gt;&lt;li&gt;The network jitter buffer is not large enough for the current network/audio interface jitter.&lt;/li&gt;&lt;li&gt;The sound card buffer delay (buffer size) is set to a too small value.&lt;/li&gt;&lt;li&gt;The upload or download stream rate is too high for the current available internet bandwidth.&lt;/li&gt;&lt;li&gt;The CPU of the client or server is at 100%.&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="181"/>
        <source>Buffers status LED indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="257"/>
        <source>&amp;Connection Setup...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="260"/>
        <source>My &amp;Profile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="263"/>
        <source>C&amp;hat...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="266"/>
        <source>&amp;Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="272"/>
        <source>&amp;Analyzer Console...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlg.cpp" line="278"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CClientDlgBase</name>
    <message>
        <location filename="../clientdlgbase.ui" line="120"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="172"/>
        <source>Buffers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="233"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="281"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="291"/>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="330"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="337"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="344"/>
        <source>Mute Myself</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="353"/>
        <source>C&amp;onnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="397"/>
        <source>Pan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="413"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="487"/>
        <source>Reverb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="553"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientdlgbase.ui" line="560"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CClientSettingsDlg</name>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="37"/>
        <source>&lt;b&gt;Jitter Buffer Size:&lt;/b&gt; The jitter buffer compensates for network and sound card timing jitters. The size of this jitter buffer has therefore influence on the quality of the audio stream (how many dropouts occur) and the overall delay (the longer the buffer, the higher the delay).&lt;br&gt;The jitter buffer size can be manually chosen for the local client and the remote server. For the local jitter buffer, dropouts in the audio stream are indicated by the light on the bottom of the jitter buffer size faders. If the light turns to red, a buffer overrun/underrun took place and the audio stream is interrupted.&lt;br&gt;The jitter buffer setting is therefore a trade-off between audio quality and overall delay.&lt;br&gt;An auto setting of the jitter buffer size setting is available. If the check Auto is enabled, the jitter buffers of the local client and the remote server are set automatically based on measurements of the network and sound card timing jitter. If the &lt;i&gt;Auto&lt;/i&gt; check is enabled, the jitter buffer size faders are disabled (they cannot be moved with the mouse).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="56"/>
        <source>In case the auto setting of the jitter buffer is enabled, the network buffers of the local client and the remote server are set to a conservative value to minimize the audio dropout probability. To &lt;b&gt;tweak the audio delay/latency&lt;/b&gt; it is recommended to disable the auto setting functionality and to &lt;b&gt;lower the jitter buffer size manually&lt;/b&gt; by using the sliders until your personal acceptable limit of the amount of dropouts is reached. The LED indicator will visualize the audio dropouts of the local jitter buffer by a red light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="72"/>
        <source>Local jitter buffer slider control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="75"/>
        <source>Server jitter buffer slider control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="77"/>
        <source>Auto jitter buffer switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="79"/>
        <source>Jitter buffer status LED indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="83"/>
        <source>&lt;b&gt;Sound Card Device:&lt;/b&gt; The ASIO driver (sound card) can be selected using </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="85"/>
        <source> under the Windows operating system. Under MacOS/Linux, no sound card selection is possible. If the selected ASIO driver is not valid an error message is shown and the previous valid driver is selected.&lt;br&gt;If the driver is selected during an active connection, the connection is stopped, the driver is changed and the connection is started again automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="92"/>
        <source>Sound card device selector combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="96"/>
        <source>In case the &lt;b&gt;ASIO4ALL&lt;/b&gt; driver is used, please note that this driver usually introduces approx. 10-30 ms of additional audio delay. Using a sound card with a native ASIO driver is therefore recommended.&lt;br&gt;If you are using the &lt;b&gt;kX ASIO&lt;/b&gt; driver, make sure to connect the ASIO inputs in the kX DSP settings panel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="105"/>
        <source>&lt;b&gt;Sound Card Channel Mapping:&lt;/b&gt; In case the selected sound card device offers more than one input or output channel, the Input Channel Mapping and Output Channel Mapping settings are visible.&lt;br&gt;For each </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="109"/>
        <source> input/output channel (Left and Right channel) a different actual sound card channel can be selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="116"/>
        <source>Left input channel selection combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="118"/>
        <source>Right input channel selection combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="120"/>
        <source>Left output channel selection combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="122"/>
        <source>Right output channel selection combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="125"/>
        <source>&lt;b&gt;Enable Small Network Buffers:&lt;/b&gt; If enabled, the support for very small network audio packets is activated. Very small network packets are only actually used if the sound card buffer delay is smaller than </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="128"/>
        <source> samples. The smaller the network buffers, the smaller the audio latency. But at the same time the network load increases and the probability of audio dropouts also increases.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="132"/>
        <source>Enable small network buffers check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="135"/>
        <source>&lt;b&gt;Sound Card Buffer Delay:&lt;/b&gt; The buffer delay setting is a fundamental setting of the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="137"/>
        <source> software. This setting has influence on many connection properties.&lt;br&gt;Three buffer sizes are supported:&lt;ul&gt;&lt;li&gt;64 samples: This is the preferred setting since it gives lowest latency but does not work with all sound cards.&lt;/li&gt;&lt;li&gt;128 samples: This setting should work on most of the available sound cards.&lt;/li&gt;&lt;li&gt;256 samples: This setting should only be used if only a very slow computer or a slow internet connection is available.&lt;/li&gt;&lt;/ul&gt;Some sound card driver do not allow the buffer delay to be changed from within the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="150"/>
        <source> software. In this case the buffer delay setting is disabled. To change the actual buffer delay, this setting has to be changed in the sound card driver. On Windows, press the ASIO Setup button to open the driver settings panel. On Linux, use the Jack configuration tool to change the buffer size.&lt;br&gt;If no buffer size is selected and all settings are disabled, an unsupported buffer size is used by the driver. The </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="157"/>
        <source> software will still work with this setting but with restricted performannce.&lt;br&gt;The actual buffer delay has influence on the connection status, the current upload rate and the overall delay. The lower the buffer size, the higher the probability of red light in the status indicator (drop outs) and the higher the upload rate and the lower the overall delay.&lt;br&gt;The buffer setting is therefore a trade-off between audio quality and overall delay.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="167"/>
        <source>If the buffer delay settings are disabled, it is prohibited by the audio driver to modify this setting from within the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="170"/>
        <source> software. On Windows, press the ASIO Setup button to open the driver settings panel. On Linux, use the Jack configuration tool to change the buffer size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="175"/>
        <source>128 samples setting radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="178"/>
        <source>256 samples setting radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="181"/>
        <source>512 samples setting radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="184"/>
        <source>ASIO setup push button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="188"/>
        <source>&lt;b&gt;Fancy Skin:&lt;/b&gt; If enabled, a fancy skin will be applied to the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="191"/>
        <source>Fancy skin check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="194"/>
        <source>&lt;b&gt;Display Channel Levels:&lt;/b&gt; If enabled, each client channel will display a pre-fader level bar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="197"/>
        <source>Display channel levels check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="200"/>
        <source>&lt;b&gt;Audio Channels:&lt;/b&gt; Select the number of audio channels to be used. There are three modes available. The mono and stereo modes use one and two audio channels respectively. In the mono-in/stereo-out mode the audio signal which is sent to the server is mono but the return signal is stereo. This is useful for the case that the sound card puts the instrument on one input channel and the microphone on the other channel. In that case the two input signals can be mixed to one mono channel but the server mix can be heard in stereo.&lt;br&gt;Enabling the stereo streaming mode will increase the stream data rate. Make sure that the current upload rate does not exceed the available bandwidth of your internet connection.&lt;br&gt;In case of the stereo streaming mode, no audio channel selection for the reverberation effect will be available on the main window since the effect is applied on both channels in this case.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="219"/>
        <source>Audio channels combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="222"/>
        <source>&lt;b&gt;Audio Quality:&lt;/b&gt; Select the desired audio quality. A low, normal or high audio quality can be selected. The higher the audio quality, the higher the audio stream data rate. Make sure that the current upload rate does not exceed the available bandwidth of your internet connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="231"/>
        <source>Audio quality combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="234"/>
        <source>&lt;b&gt;New Client Level:&lt;/b&gt; The new client level setting defines the fader level of a new connected client in percent. I.e. if a new client connects to the current server, it will get the specified initial fader level if no other fader level of a previous connection of that client was already stored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="243"/>
        <source>New client level edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="246"/>
        <source>&lt;b&gt;Central Server Address:&lt;/b&gt; The central server address is the IP address or URL of the central server at which the server list of the connection dialog is managed. With the central server address type either the local region can be selected of the default central servers or a manual address can be specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="256"/>
        <source>Default central server type combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="257"/>
        <source>Central server address line edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="260"/>
        <source>&lt;b&gt;Current Connection Status Parameter:&lt;/b&gt; The ping time is the time required for the audio stream to travel from the client to the server and backwards. This delay is introduced by the network. This delay should be as low as 20-30 ms. If this delay is higher (e.g., 50-60 ms), your distance to the server is too large or your internet connection is not sufficient.&lt;br&gt;The overall delay is calculated from the current ping time and the delay which is introduced by the current buffer settings.&lt;br&gt;The upstream rate depends on the current audio packet size and the audio compression setting. Make sure that the upstream rate is not higher than the available rate (check the upstream capabilities of your internet connection by, e.g., using speedtest.net).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="281"/>
        <source>If this LED indicator turns red, you will not have much fun using the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="283"/>
        <source> software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="633"/>
        <source>The selected audio device could not be used because of the following error: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlg.cpp" line="635"/>
        <source> The previous driver will be selected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CClientSettingsDlgBase</name>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="27"/>
        <source>Soundcard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="33"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="83"/>
        <source>Input Channel Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="103"/>
        <location filename="../clientsettingsdlgbase.ui" line="160"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="116"/>
        <location filename="../clientsettingsdlgbase.ui" line="173"/>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="140"/>
        <source>Output Channel Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="213"/>
        <source>Enable Small Network Buffers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="220"/>
        <source>Buffer Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="226"/>
        <source>(preferred)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="233"/>
        <source>(default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="240"/>
        <source>(safe)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="247"/>
        <source>Driver Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="263"/>
        <source>Jitter Buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="269"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="284"/>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="303"/>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="326"/>
        <location filename="../clientsettingsdlgbase.ui" line="345"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="483"/>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="493"/>
        <source>Audio Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="500"/>
        <source>Audio Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="507"/>
        <source>New Client Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="529"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="544"/>
        <source>Fancy Skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="551"/>
        <source>Display Channel Levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="562"/>
        <source>Central Server Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="599"/>
        <source>Audio Stream Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="612"/>
        <location filename="../clientsettingsdlgbase.ui" line="642"/>
        <location filename="../clientsettingsdlgbase.ui" line="677"/>
        <source>val</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="623"/>
        <source>Ping Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientsettingsdlgbase.ui" line="653"/>
        <source>Overall Delay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CConnectDlg</name>
    <message>
        <location filename="../connectdlg.cpp" line="47"/>
        <source>&lt;b&gt;Server List:&lt;/b&gt; The server list shows a list of available servers which are registered at the central server. Select a server from the list and press the connect button to connect to this server. Alternatively, double click a server from the list to connect to it. If a server is occupied, a list of the connected musicians is available by expanding the list item. Permanent servers are shown in bold font.&lt;br&gt;Note that it may take some time to retrieve the server list from the central server. If no valid central server address is specified in the settings, no server list will be available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="58"/>
        <source>Server list view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="61"/>
        <source>&lt;b&gt;Server Address:&lt;/b&gt; The IP address or URL of the server running the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="62"/>
        <source> server software must be set here. An optional port number can be added after the IP address or URL using a comma as a separator, e.g, &lt;i&gt;example.org:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="66"/>
        <source>&lt;/i&gt;. A list of the most recent used server IP addresses or URLs is available for selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="73"/>
        <source>Server address edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="74"/>
        <source>Holds the current server IP address or URL. It also stores old URLs in the combo box list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="78"/>
        <source>&lt;b&gt;Filter:&lt;/b&gt; The server list is filered by the given text. Note that the filter is case insensitive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="80"/>
        <source>Filter edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="83"/>
        <source>&lt;b&gt;Show All Musicians:&lt;/b&gt; If you check this check box, the musicians of all servers are shown. If you uncheck the check box, all list view items are collapsed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlg.cpp" line="86"/>
        <source>Show all musicians check box</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CConnectDlgBase</name>
    <message>
        <location filename="../connectdlgbase.ui" line="14"/>
        <source>Connection Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="35"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="45"/>
        <source>Show All Musicians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="61"/>
        <source>Server Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="66"/>
        <source>Ping Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="71"/>
        <source>Musicians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="76"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="86"/>
        <source>Server Name/Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="120"/>
        <source>C&amp;ancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../connectdlgbase.ui" line="127"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CHelpMenu</name>
    <message>
        <location filename="../util.cpp" line="812"/>
        <source>What&apos;s &amp;This</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="816"/>
        <source>&amp;Download Link...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="820"/>
        <source>&amp;About...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CLicenceDlg</name>
    <message>
        <location filename="../util.cpp" line="483"/>
        <source>By connecting to this server and agreeing to this notice, you agree to the following:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="485"/>
        <source>You agree that all data, sounds, or other works transmitted to this server are owned and created by you or your licensors, and that you are making these data, sounds or other works available via the following Creative Commons License (for more information on this license, see &lt;i&gt;&lt;a href=http://creativecommons.org/licenses/by-nc-sa/4.0&gt;http://creativecommons.org/licenses/by-nc-sa/4.0&lt;/a&gt;&lt;/i&gt;):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="493"/>
        <source>You are free to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="495"/>
        <source>Share</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="496"/>
        <source>copy and redistribute the material in any medium or format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="497"/>
        <source>Adapt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="498"/>
        <source>remix, transform, and build upon the material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="499"/>
        <source>The licensor cannot revoke these freedoms as long as you follow the license terms.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="501"/>
        <source>Under the following terms:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="503"/>
        <source>Attribution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="504"/>
        <source>You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="507"/>
        <source>NonCommercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="508"/>
        <source>You may not use the material for commercial purposes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="509"/>
        <source>ShareAlike</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="510"/>
        <source>If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="512"/>
        <source>No additional restrictions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="513"/>
        <source>You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CMusProfDlg</name>
    <message>
        <location filename="../util.cpp" line="673"/>
        <source>&lt;b&gt;Musician Profile:&lt;/b&gt; Set your name or an alias here so that the other musicians you want to play with know who you are. Additionally you may set an instrument picture of the instrument you play and a flag of the country you are living. The city you live in and the skill level of playing your instrument may also be added.
What you set here will appear at your fader on the mixer board when you are connected to a </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="680"/>
        <source> server. This tag will also show up at each client which is connected to the same server as you. If the name is left empty, the IP address is shown instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="685"/>
        <source>Alias or name edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="687"/>
        <source>Instrument picture button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="689"/>
        <source>Country flag button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="691"/>
        <source>City edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../util.cpp" line="693"/>
        <source>Skill level combo box</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CServerDlg</name>
    <message>
        <location filename="../serverdlg.cpp" line="45"/>
        <source>&lt;b&gt;Client List:&lt;/b&gt; The client list shows all clients which are currently connected to this server. Some information about the clients like the IP address and name are given for each connected client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="50"/>
        <source>Connected clients list view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="53"/>
        <source>&lt;b&gt;Start Minimized on Operating System Start:&lt;/b&gt; If the start minimized on operating system start check box is checked, the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="55"/>
        <source> server will be started when the operating system starts up and is automatically minimized to a system task bar icon.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="60"/>
        <source>&lt;b&gt;Show Creative Commons Licence Dialog:&lt;/b&gt; If enabled, a Creative Commons Licence dialog is shown each time a new user connects the server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="65"/>
        <source>&lt;b&gt;Make My Server Public:&lt;/b&gt; If the Make My Server Public check box is checked, this server registers itself at the central server so that all </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="68"/>
        <source> users can see the server in the connect dialog server list and connect to it. The registering of the server is renewed periodically to make sure that all servers in the connect dialog server list are actually available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="74"/>
        <source>&lt;b&gt;Register Server Status:&lt;/b&gt; If the Make My Server Public check box is checked, this will show the success of registration with the central server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="79"/>
        <source>&lt;b&gt;Central Server Address:&lt;/b&gt; The Central server address is the IP address or URL of the central server at which this server is registered. With the central server address type either the local region can be selected of the default central servers or a manual address can be specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="89"/>
        <source>Default central server type combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="90"/>
        <source>Central server address line edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="93"/>
        <source>&lt;b&gt;Server Name:&lt;/b&gt; The server name identifies your server in the connect dialog server list at the clients. If no name is given, the IP address is shown instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="100"/>
        <source>Server name line edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="103"/>
        <source>&lt;b&gt;Location City:&lt;/b&gt; The city in which this server is located can be set here. If a city name is entered, it will be shown in the connect dialog server list at the clients.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="110"/>
        <source>City where the server is located line edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="114"/>
        <source>&lt;b&gt;Location country:&lt;/b&gt; The country in which this server is located can be set here. If a country is entered, it will be shown in the connect dialog server list at the clients.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="122"/>
        <source>Country where the server is located combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="135"/>
        <location filename="../serverdlg.cpp" line="278"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="141"/>
        <source>&amp;Hide </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="141"/>
        <location filename="../serverdlg.cpp" line="145"/>
        <location filename="../serverdlg.cpp" line="151"/>
        <source> server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="145"/>
        <source>&amp;Open </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="167"/>
        <source> server </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlg.cpp" line="272"/>
        <source> Server</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CServerDlgBase</name>
    <message>
        <location filename="../serverdlgbase.ui" line="34"/>
        <source>Client IP:Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="39"/>
        <location filename="../serverdlgbase.ui" line="125"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="44"/>
        <source>Jitter Buffer Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="52"/>
        <source>Start Minimized on Windows Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="59"/>
        <source>Show Creative Commons Licence Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="68"/>
        <source>Make My Server Public (Register My Server in the Server List)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="91"/>
        <source>STATUS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="102"/>
        <source>Central Server Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="117"/>
        <source>My Server Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="132"/>
        <source>Location: City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="139"/>
        <source>Location: Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../serverdlgbase.ui" line="181"/>
        <source>TextLabelNameVersion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CSound</name>
    <message>
        <location filename="../../linux/sound.cpp" line="39"/>
        <source>The Jack server is not running. This software requires a Jack server to run. Normally if the Jack server is not running this software will automatically start the Jack server. It seems that this auto start has not worked. Try to start the Jack server manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="59"/>
        <source>The Jack server sample rate is different from the required one. The required sample rate is: &lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="61"/>
        <source> Hz&lt;/b&gt;. You can use a tool like &lt;i&gt;&lt;a href=http://qjackctl.sourceforge.net&gt;QJackCtl&lt;/a&gt;&lt;/i&gt; to adjust the Jack server sample rate.&lt;br&gt;Make sure to set the &lt;b&gt;Frames/Period&lt;/b&gt; to a low value like &lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="66"/>
        <source>&lt;/b&gt; to achieve a low delay.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="87"/>
        <location filename="../../linux/sound.cpp" line="98"/>
        <source>The Jack port registering failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="109"/>
        <source>Cannot activate the Jack client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="128"/>
        <location filename="../../linux/sound.cpp" line="137"/>
        <source>Cannot connect the Jack input ports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="152"/>
        <location filename="../../linux/sound.cpp" line="161"/>
        <source>Cannot connect the Jack output ports.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../linux/sound.cpp" line="350"/>
        <source>The Jack server was shut down. This software requires a Jack server to run. Try to restart the software to solve the issue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="100"/>
        <source>CoreAudio input AudioHardwareGetProperty call failed. It seems that no sound card is available in the system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="114"/>
        <source>CoreAudio output AudioHardwareGetProperty call failed. It seems that no sound card is available in the system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="360"/>
        <source>Current system audio input device sample rate of %1 Hz is not supported. Please open the Audio-MIDI-Setup in Applications-&gt;Utilities and try to set a sample rate of %2 Hz.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="387"/>
        <source>Current system audio output device sample rate of %1 Hz is not supported. Please open the Audio-MIDI-Setup in Applications-&gt;Utilities and try to set a sample rate of %2 Hz.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="460"/>
        <source>The audio input stream format for this audio device is not compatible with this software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="481"/>
        <source>The audio output stream format for this audio device is not compatible with this software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mac/sound.cpp" line="703"/>
        <source>The buffer sizes of the current input and output audio device cannot be set to a common value. Please choose other input/output audio devices in your system settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="53"/>
        <source>The audio driver could not be initialized.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="108"/>
        <source>The audio device does not support the required sample rate. The required sample rate is: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="121"/>
        <source>The audio device does not support to set the required sampling rate. This error can happen if you have an audio interface like the Roland UA-25EX where you set the sample rate with a hardware switch on the audio device. If this is the case, please change the sample rate to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="125"/>
        <source> Hz on the device and restart the </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="126"/>
        <source> software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="136"/>
        <source>The audio device does not support the required number of channels. The required number of channels for input and output is: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="172"/>
        <location filename="../../windows/sound.cpp" line="202"/>
        <source>Required audio sample format not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="517"/>
        <source>&lt;b&gt;No ASIO audio device (driver) found.&lt;/b&gt;&lt;br&gt;&lt;br&gt;The </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../windows/sound.cpp" line="518"/>
        <source> software requires the low latency audio interface &lt;b&gt;ASIO&lt;/b&gt; to work properly. This is no standard Windows audio interface and therefore a special audio driver is required. Either your sound card has a native ASIO driver (which is recommended) or you might want to use alternative drivers like the ASIO4All driver.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CSoundBase</name>
    <message>
        <location filename="../soundbase.cpp" line="117"/>
        <source>Invalid device selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../soundbase.cpp" line="143"/>
        <source>The audio driver properties have changed to a state which is incompatible to this software. The selected audio device could not be used because of the following error: &lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../soundbase.cpp" line="148"/>
        <source>&lt;/b&gt;&lt;br&gt;&lt;br&gt;Please restart the software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../soundbase.cpp" line="191"/>
        <source>&lt;b&gt;No usable </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../soundbase.cpp" line="192"/>
        <source> audio device (driver) found.&lt;/b&gt;&lt;br&gt;&lt;br&gt;In the following there is a list of all available drivers with the associated error message:&lt;ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../soundbase.cpp" line="207"/>
        <source>&lt;br/&gt;Do you want to open the ASIO driver setups?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../soundbase.cpp" line="214"/>
        <source> could not be started because of audio interface issues.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
